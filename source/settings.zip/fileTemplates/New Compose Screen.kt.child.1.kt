#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.stateIn

class ${NAME}ScreenViewModel : BaseViewModel<${NAME}ScreenContent>() {
        
        ovveride fun getInitialContent(): ${NAME}ScreenContent {
          return ${NAME}ScreenContent()
        }
        
        fun onAction(action: ${NAME}ScreenAction) {
            when(action) {
                else -> TODO("Handle actions")
            }
        }

}