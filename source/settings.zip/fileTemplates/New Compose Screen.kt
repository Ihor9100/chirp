#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "") package ${PACKAGE_NAME} #end
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun ${NAME}Screen(
    viewModel: ${NAME}ScreenViewModel = viewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    
    BaseScreen(
      baseContent = state.baseContent
    ) {
      ${NAME}ScreenContent(
        content = state.content,
        onAction = viewModel::onAction
      )
    }
}

@Composable
fun ${NAME}ScreenContent(
    content: ${NAME}ScreenContent,
    onAction: (${NAME}ScreenAction) -> Unit,
) {

}

@Preview
@Composable
private fun ${NAME}ScreenPreview() {
    ${PROJECT_NAME}Theme {
        ${NAME}ScreenContent(
            content = ${NAME}ScreenContent(),
            onAction = {}
        )
    }
}