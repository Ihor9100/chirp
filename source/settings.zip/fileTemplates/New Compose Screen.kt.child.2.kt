#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end

data class ${NAME}ScreenContent(
    val paramOne: String = "default",
    val paramTwo: List<String> = emptyList(),
)